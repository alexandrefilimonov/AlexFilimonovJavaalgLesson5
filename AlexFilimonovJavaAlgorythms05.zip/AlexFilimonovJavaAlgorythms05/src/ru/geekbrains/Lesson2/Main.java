package ru.geekbrains.Lesson2;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.*;
import java.lang.String;
import java.lang.Object;
import java.util.ArrayList;

public class Main {
    private static ArrayList<Item> items;
    private static void addItems() {
        items = new ArrayList<Item>();
        items.add(new Item("Book",2,600));
        items.add(new Item("Pencil",2,5000));
        items.add(new Item("Calculator",3,1500));
        items.add(new Item("Computer",4,40000));
        items.add(new Item("T-shirt",1,500));
        items.add(new Item("Shirt",1,800));
        items.add(new Item("Towel",1,700));
    }

    private static void showItems(ArrayList<Item> _items) {
        //itemsListView.Items.Clear();
        for (Item i : _items)
        {
            System.out.println( "\nItem Name: "+i.getname()+" Item weight: "+String.valueOf(i.getweigth())+" Item value: "+String.valueOf(i.getprice()));
        }
    }
    public static void main( String [] args ) {
        addItems();
        showItems(items);

        int iMaxWeight= 9;
        Backpack bp = new Backpack((double)iMaxWeight);
        bp.makeAllSets(items);
        ArrayList<Item> solve = bp.getBestSet();
        if (solve == null)
            System.out.println( "There is no solution!");
        else {
            //itemsListView.Items.Clear();
            System.out.println( "\nSolution for size:"+iMaxWeight+" - "+solve.size()+" items!");
            showItems(solve);
        }
    }

}




